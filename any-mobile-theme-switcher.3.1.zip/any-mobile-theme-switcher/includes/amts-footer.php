 </td>
        <td width="15">&nbsp;</td>
        <td width="250" valign="top">
        	 <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Support</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>If you have any issues, click <a href="http://dineshkarki.com.np/forums/forum/mobile-theme-switcher" target="_blank">here</a> to visit our support forum</td>
                </tr>
                </tbody>
            </table>
            <br/>
            	
             <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Any Mobile Theme Switcher Pro</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td style="color:#0F0;">
                    <a href="https://dineshkarki.com.np/any-mobile-theme-switcher/buy-pro-version" title="Any Mobile Theme Switcher Pro" target="_blank">
                    <div style="color:#08aa00; font-style:italic; font-size:27px; line-height:30px; text-align:center;">Any Mobile Theme Switcher Pro</div>
                    
                   <style>
				   	ul.proFeature{ list-style:square; padding-left:20px;}
					ul.proFeature li{color:#910000; font-size:14px; line-height:14px;}
                   </style>
                   <ul class="proFeature">
                    	<li>Works With W3 Total Cache</li>
                        <li>Different Home Page based on mobile devices</li>
                        <li>QR code images to allow mobile users for easy bookmarking and access</li>
                        <li>More powerfull mobile detection.</li>
                        <li>Click to call for phone numbers</li>
                    </ul>
                    
                    
                    <div style="color:#910000; font-style:italic; font-size:20px; line-height:30px; text-align:center;">Get Pro version now</div>
                    
                    </a>
                    </td>
                </tr>
                </tbody>
            </table>
            
            <br/>
            
           
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Plugins You May Like</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    	<ol>
                        	<li><a target="_blank" href="https://wordpress.org/plugins/use-any-font">Use Any Font</a></li>
                            <li><a target="_blank" href="https://wordpress.org/plugins/honeypot/">WP Armour Anti Spam Plugin</a></li>
                            <li><a target="_blank" href="https://dineshkarki.com.np/jquery-validation-for-gravity-forms">jQuery Validation for Gravity Forms</a></li>
                            <li><a target="_blank" href="https://wordpress.org/plugins/jquery-validation-for-contact-form-7/">jQuery Validation For Contact Form 7</a></li>
                            <li><a target="_blank" href="https://wordpress.org/plugins/block-specific-plugin-updates/">Block Specific Plugin Updates</a></li>
                            <li><a target="_blank" href="https://wordpress.org/plugins/featured-image-in-rss-feed/">Featured Image In RSS Feed</a></li>
                            <li><a target="_blank" href="https://wordpress.org/plugins/add-tags-and-category-to-page/">Add Tags And Category To Page</a></li>
                        </ol>
                    </td>
                </tr>
                </tbody>
            </table>            
        </td>
    </tr>
</table>


</div>