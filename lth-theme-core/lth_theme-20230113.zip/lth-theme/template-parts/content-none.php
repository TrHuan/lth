<?php
/**
 * Template hiển thị khi thông báo không tìm thấy posts nào
 * 
 * @author LTH
 * @since 2020
 */
?>

<div class="not-found">
    <?php echo wpautop(__('Xin lỗi, không có dữ liệu nào được tìm thấy.')); ?>
</div>