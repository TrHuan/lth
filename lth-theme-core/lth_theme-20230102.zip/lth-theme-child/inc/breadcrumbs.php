<section class="breadcrumbs breadcrumbs-child">
    <?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-image.php'); ?>

    <article class="breadcrumb-content">
        <div class="container">
            <?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-content.php'); ?>
        </div>
    </article>
</section>