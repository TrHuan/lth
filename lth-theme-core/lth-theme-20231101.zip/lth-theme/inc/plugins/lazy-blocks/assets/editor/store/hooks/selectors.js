/**
 * Internal dependencies
 */
import useBlockControlProps from '../../../hooks/use-block-control-props';

export function get() {
	return {
		useBlockControlProps,
	};
}
