<?php

/**
 * Template Name: Full Width
 * 
 * @author LTH
 * @since 2020
 */
?>
<?php get_header(); ?>

<main class="main main-full-width">
    <?php the_content(); ?>
</main>

<?php get_footer(); ?>