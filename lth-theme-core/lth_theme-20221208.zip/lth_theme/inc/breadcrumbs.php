
<section class="breadcrumbs">
	<?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-image.php'); ?>
    
    <article class="container">
    	<?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-content.php'); ?>        
    </article>
</section>