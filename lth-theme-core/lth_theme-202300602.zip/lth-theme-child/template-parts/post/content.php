<div class="item">
    <div class="post-box">
        <?php if (has_post_thumbnail()) { ?>
            <div class="post-image">
                <a href="<?php the_permalink(); ?>" title="" class="image">
                    <picture>
						<source media="(min-width:1200px)" srcset="<?php echo lth_custom_img('full', 370, 370); ?>">
						<source media="(min-width:768px)" srcset="<?php echo lth_custom_img('full', 330, 330); ?>">
						<source media="(min-width:576px)" srcset="<?php echo lth_custom_img('full', 240, 240); ?>">
						<img src="<?php echo lth_custom_img('full', 420, 420); ?>" width="420" height="420" alt="<?php the_title(); ?>">
					</picture>
                </a>
            </div>
        <?php } ?>

        <div class="post-content">
            <h3 class="post-name">
                <a href="<?php the_permalink(); ?>" title="">
                    <?php the_title(); ?>
                </a>
            </h3>

            <ul class="post-meta">
			    <li class="post-days">
			        <i class="fal fa-calendar-alt icon"></i>
                    <span><?php the_time('d'); ?> <?php echo __('Thg '); the_time('m,'); ?> <?php the_time('Y'); ?></span>
			    </li>

			    <li class="post-poster">
                    <i class="far fa-user icon"></i>
                    <span><?php the_author(	); ?></span>
                </li>

                <li class="post-eye">
                    <i class="fal fa-eye icon" aria-hidden="true"> </i>
                    <?php echo getPostViews(get_the_ID()); ?>
                </li>
	    	</ul>	 

            <div class="post-excerpt">
                <?php wpautop(the_excerpt()); ?>
            </div>

            <div class="post-button">
                <a href="<?php the_permalink(); ?>" class="btn" title="">
                    <?php echo __('Chi tiết'); ?>
                </a>
            </div>
        </div>
    </div>
</div>