<?php

require get_theme_file_path('inc/theme-options/theme-options.php');

require get_theme_file_path('inc/theme-options/theme-options-fields.php');
