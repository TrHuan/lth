jQuery(document).ready(function ($) {
    var url_logo = header_script.logo;
    var url_favicon = header_script.favicon;
    var menu = header_script.menu;

    $('#header').html(function () {
        var logo = '<div class="logo">'
            + '<image src="' + url_logo + '">' +
            '</div>';

        var menu2 = '<div class="megamenu">'
            + menu +
            '</div>';

        return logo + menu2;
    });
});
