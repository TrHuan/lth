
jQuery(document).ready(function ($) {
    var get_content = content_script.content;

    $('#page-content').html(function () {
        var content = get_content;

        return content;
    });
});


