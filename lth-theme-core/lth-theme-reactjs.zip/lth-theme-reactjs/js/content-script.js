
jQuery(document).ready(function ($) {
    var get_content = content_script.content;

    $('#acfDataContainer').html(function () {
        var content = get_content;

        return content;
    });
});


