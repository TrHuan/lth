<?php
// đường dẫn theme
define('THEME_DIR', get_template_directory());
define('THEME_URI', get_template_directory_uri());

// đường dẫn thư viện
define('LIBS_DIR', THEME_DIR . '/inc');

// theme options
require_once(LIBS_DIR . '/plugins/acf/acf.php');

require_once(LIBS_DIR . '/theme-options.php');

function header_script() {
    $logo = get_field('logo', 'option');
    $favicon = get_field('favicon', 'option');

    $menu_name = 'main-menu';
    $menu = wp_nav_menu( array(
        'theme_location' => $menu_name,
        'echo' => false,
    ) );

    wp_enqueue_script('header-script', THEME_URI . '/js/header-script.js', array('jquery'), '', true);

    wp_localize_script('header-script', 'header_script', array(
        'logo' => $logo,
        'favicon' => $favicon,
        'menu' => $menu,
    ));
}
add_action('wp_enqueue_scripts', 'header_script');

