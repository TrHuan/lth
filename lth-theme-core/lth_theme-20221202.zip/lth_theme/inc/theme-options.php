<?php

require_once(LIBS_DIR . '/theme-options/theme-options.php');

require_once(LIBS_DIR . '/theme-options/theme-options-fields.php');