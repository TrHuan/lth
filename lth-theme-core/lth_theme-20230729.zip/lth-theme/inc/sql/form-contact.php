<div class="contacts-form">
    <div class="form-group">
        [text* your-name placeholder "Họ tên"]
    </div>

    <div class="form-group">
        [email* your-email placeholder "Email"]
    </div>

    <div class="form-group">
        [tel* your-phone minlength:10 maxlength:11 placeholder "Số điện thoại"]
    </div>


    <div class="form-group">
        [textarea your-message placeholder "Nội dung"]
    </div>

    <div class="form-group form-group-button">
        <div class="form-button">
            [submit "Gửi"]
        </div>
    </div>
</div>