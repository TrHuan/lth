// This script is used for JS translations only.
// Check lazy-blocks.php for more info.
