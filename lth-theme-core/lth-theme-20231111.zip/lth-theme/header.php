<?php

/**
 * Header
 * @author LTH
 * @since 2020
 */
?>
<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo get_option('blogname'); ?> - <?php echo get_option('blogdescription'); ?>">
    <meta name="keywords" content="Php, HTML, CSS, JavaScript">
    <meta name="author" content="LTH">
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" /> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="robots" content="index" />
    <meta name="AdsBot-Google" content="noindex" />
    <meta name="Googlebot" content="noindex">  

    <link rel="icon" href="<?php the_field('favicon', 'option'); ?>" type="image/gif">

    <?php if (is_tax()) { ?>
        <link rel="canonical" href="<?php echo get_term_link($term, $taxonomy); ?>" />
    <?php } elseif (is_category()) { ?>
        <link rel="canonical" href="<?php echo get_category_link(get_the_category()[0]->term_id); ?>" />
    <?php } else { ?>
        <?php if (get_post_type() == 'product' && !is_single()) {
            $shop_page_url = get_permalink(woocommerce_get_page_id('shop'));
        ?>
            <link rel="canonical" href="<?php echo $shop_page_url; ?>" />
        <?php } else { ?>
            <link rel="canonical" href="<?php the_permalink(); ?>" />
        <?php } ?>
    <?php } ?>

    <!-- hook của wordpress gọi đến file inc/head.php -->
    <?php wp_head(); ?>

    <?php
        $other = get_field('other', 'option');
        echo $other['code_head'];

        if (is_tax() || is_category()) {
            $term = get_queried_object();
            $code_head = get_field('code_head', $term);
            if ($code_head) {
                echo $code_head;
            }
        } else {
            $code_head = get_field('code_head');
            if ($code_head) {
                echo $code_head;
            }
        }
    ?>
</head>

<?php
$ptp = get_post_type();

if ($ptp == 'product' && !is_search() || is_tax()) {
    $dat_url = get_permalink(woocommerce_get_page_id('shop'));
}
?>

<body <?php body_class(); ?> <?php if (isset($dat_url)) { ?>data_url="<?php echo $dat_url; ?>" <?php } ?>>

    <header class="header">
        <?php $header_option = get_field('header_top', 'option');
        if ($header_option) { ?>
            <div class="header-top">
                <?php $args = [
                    'post_type' => 'html-blocks',
                    'p' => $header_option,
                ];
                $lth = new WP_Query($args);
                if ($lth->have_posts()) { ?>
                    <?php while ($lth->have_posts()) {
                        $lth->the_post();
                        //load file tương ứng với post format
                        the_content();
                    }
                }
                // reset post data
                wp_reset_postdata(); ?>
            </div>
        <?php } ?>
        <div class="header-stick">
            <?php $header_option = get_field('header_stick', 'option');
            if ($header_option) {
                $args = [
                    'post_type' => 'html-blocks',
                    'p' => $header_option,
                ];
                $lth = new WP_Query($args);
                if ($lth->have_posts()) { ?>
                    <?php while ($lth->have_posts()) {
                        $lth->the_post();
                        //load file tương ứng với post format
                        the_content();
                    }
                }
                // reset post data
                wp_reset_postdata();
            } ?>
        </div>
        <?php $header_option = get_field('header_bottom', 'option');
        if ($header_option) { ?>
            <div class="header-bottom">
                <?php $args = [
                    'post_type' => 'html-blocks',
                    'p' => $header_option,
                ];
                $lth = new WP_Query($args);
                if ($lth->have_posts()) { ?>
                    <?php while ($lth->have_posts()) {
                        $lth->the_post();
                        //load file tương ứng với post format
                        the_content();
                    }
                }
                // reset post data
                wp_reset_postdata(); ?>
            </div>
        <?php } ?>
    </header>