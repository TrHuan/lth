(function($) {
    // "use strict";

    var slider = function ($scope, $) {
        var slick = $(".swiper-slidershow");
        slick.each(function(){
            var item        = $(this).data('item'),
                item_lg     = $(this).data('item_lg'),
                item_md     = $(this).data('item_md'),
                item_sm     = $(this).data('item_sm'),
                item_mb     = $(this).data('item_mb'),
                row         = $(this).data('row'),
                arrows      = $(this).data('arrows'),
                dots        = $(this).data('dots'),
                vertical    = $(this).data('vertical');
                autoplay    = $(this).data('autoplay');
            $(this).slick({
                loop: true,
                autoplay: autoplay,
                infinite: true,
                autoplaySpeed: 2000,
                vertical: vertical,
                rows: row,
                slidesToShow: item,
                slidesToScroll: 1,
                lazyLoad: 'ondemand',
                // verticalSwiping: true,
                dots: dots,
                arrows: arrows,
                prevArrow: '<a class="slick-arrow slick-prev" href="javascript:0"><i class="icofont-thin-left icon"></i></a>',
                nextArrow: '<a class="slick-arrow slick-next" href="javascript:0"><i class="icofont-thin-right icon"></i></a>',
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: item_lg,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: item_md,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: item_sm,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 576,
                        settings: {
                            slidesToShow: item_mb,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        });
    };
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/lth-slider.default', slider);
    });

    var posts = function ($scope, $) {
        var slick = $(".swiper-blogs");
        slick.each(function(){
            var item        = $(this).data('item'),
                item_lg     = $(this).data('item_lg'),
                item_md     = $(this).data('item_md'),
                item_sm     = $(this).data('item_sm'),
                item_mb     = $(this).data('item_mb'),
                row         = $(this).data('row'),
                arrows      = $(this).data('arrows'),
                dots        = $(this).data('dots'),
                vertical    = $(this).data('vertical');
                autoplay    = $(this).data('autoplay');
            $(this).slick({
                loop: true,
                autoplay: autoplay,
                infinite: true,
                autoplaySpeed: 2000,
                vertical: vertical,
                rows: row,
                slidesToShow: item,
                slidesToScroll: 1,
                lazyLoad: 'ondemand',
                // verticalSwiping: true,
                dots: dots,
                arrows: arrows,
                prevArrow: '<a class="slick-arrow slick-prev" href="javascript:0"><i class="icofont-thin-left icon"></i></a>',
                nextArrow: '<a class="slick-arrow slick-next" href="javascript:0"><i class="icofont-thin-right icon"></i></a>',
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: item_lg,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: item_md,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: item_sm,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 576,
                        settings: {
                            slidesToShow: item_mb,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        });
    };
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/lth-posts.default', posts);
    });

    var products = function ($scope, $) {
        var slick = $(".swiper-products");
        slick.each(function(){
            var item        = $(this).data('item'),
                item_lg     = $(this).data('item_lg'),
                item_md     = $(this).data('item_md'),
                item_sm     = $(this).data('item_sm'),
                item_mb     = $(this).data('item_mb'),
                row         = $(this).data('row'),
                arrows      = $(this).data('arrows'),
                dots        = $(this).data('dots'),
                vertical    = $(this).data('vertical');
                autoplay    = $(this).data('autoplay');
            $(this).slick({
                loop: true,
                autoplay: autoplay,
                infinite: true,
                autoplaySpeed: 2000,
                vertical: vertical,
                rows: row,
                slidesToShow: item,
                slidesToScroll: 1,
                lazyLoad: 'ondemand',
                // verticalSwiping: true,
                dots: dots,
                arrows: arrows,
                prevArrow: '<a class="slick-arrow slick-prev" href="javascript:0"><i class="icofont-thin-left icon"></i></a>',
                nextArrow: '<a class="slick-arrow slick-next" href="javascript:0"><i class="icofont-thin-right icon"></i></a>',
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: item_lg,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: item_md,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: item_sm,
                            slidesToScroll: 1,
                        }
                    },
                    {
                        breakpoint: 576,
                        settings: {
                            slidesToShow: item_mb,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        });
    };
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/lth-products.default', products);
    });

})(jQuery);