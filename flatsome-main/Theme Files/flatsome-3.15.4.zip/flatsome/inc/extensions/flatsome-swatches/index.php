<?php // @codingStandardsIgnoreLine


namespace Flatsome\Extensions;

defined( 'ABSPATH' ) || exit;


global $extensions_url;
require $extensions_url . '/flatsome-swatches/includes/class-swatches.php';

flatsome_swatches();

