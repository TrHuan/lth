<?php

/**
 * GCO UX Elements.
 */

require get_theme_file_path() . '/inc/elements/button.php';
require get_theme_file_path() . '/inc/elements/ux_image.php';