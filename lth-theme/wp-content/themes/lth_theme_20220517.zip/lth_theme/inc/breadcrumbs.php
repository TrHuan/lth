
<div class="breadcrumbs">
	<?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-image.php'); ?>
	
    <section class="container mb-50s">
    	<?php require_once(LIBS_DIR . '/breadcrumbs/breadcrumb-content.php'); ?>        
    </section>
</div>