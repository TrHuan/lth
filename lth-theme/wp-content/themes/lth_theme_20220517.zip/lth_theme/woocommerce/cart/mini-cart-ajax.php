
<div class="cart-content">
	<div class="cart-list">
		<div class="cart-container-list">
			<div class="cart-close" >
				<i class="far fa-times icon"></i>
			</div>
			<?php woocommerce_mini_cart(); ?>
		</div>
	</div>
</div>
	