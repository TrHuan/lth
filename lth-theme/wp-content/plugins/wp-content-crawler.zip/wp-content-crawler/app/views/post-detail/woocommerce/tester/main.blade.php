<div class="details woocommerce" id="woocommerce-details">
    <h2>
        <span>{{ _wpcc('WooCommerce') }}</span>
        <button class="button go-to-top">{{ _wpcc('Go to top') }}</button>
    </h2>
    <div class="inside">
        @include('post-detail.woocommerce.tester.woocommerce-tester')
    </div>
</div>