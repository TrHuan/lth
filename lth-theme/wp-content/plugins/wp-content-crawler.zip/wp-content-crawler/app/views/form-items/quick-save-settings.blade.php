<div class="quick-save-container">
    <button type="button" class="quick-save animated"
            data-post-id="{{ $postId }}" title="{{ "Quick save" }}">
        <span class="dashicons dashicons-yes"></span>
    </button>
</div>