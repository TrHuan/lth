<div class="input-group">
    <div class="input-container">
        @include('form-items.partials.categories', [
            'name'          => $name,
            'categories'    => $categories,
        ])
    </div>
</div>