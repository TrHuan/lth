<tr data-id="section-{{ str_slug($title) }}">
    <td colspan="2">
        <h4 class="section-title">{!! $title !!}</h4>
    </td>
</tr>