interface JQuery {
    serializeObjectNoNull: any;
    tooltip: any;
    notify: any;
    sortable: any;
}

interface JQueryStatic {
    featherlight: any;
    notify: any;
}

interface WPCC_POST_SETTINGS {
    prepareTestData: any;
    addSettingsToAjaxData: any;
}

interface Window {
    ajaxurl: string;
    pageActionKey: string;
    WPCC_POST_SETTINGS: WPCC_POST_SETTINGS;
    wpcc: any;
    OptimalSelect: any;
    Clipboard: any;
    jQuery: any;
    optionsBox: any;
    $lastClickedOptionsBoxButton: any;
    tinymce: any;
    tinyMCE: any;
}