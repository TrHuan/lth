import {SiteTester} from "./app/SiteTester";

// Initialize when document is ready
jQuery(function($) {
    // Initialize the site tester
    new SiteTester();
});