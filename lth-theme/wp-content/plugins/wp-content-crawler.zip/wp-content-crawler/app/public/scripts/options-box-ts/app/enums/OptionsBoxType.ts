export enum OptionsBoxType {

    // These must be the same as the enums in OptionsBoxType.php
    DEF     = 'default',
    FILE    = 'file'

}