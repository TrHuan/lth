import {BaseUrlData} from "./BaseUrlData";

export class CategoryUrlData extends BaseUrlData {

}