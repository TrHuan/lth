import {PostSettings} from "./app/PostSettings";

function l(v: any) { console.log(v); }

jQuery(function($) {
    PostSettings.getInstance();
});