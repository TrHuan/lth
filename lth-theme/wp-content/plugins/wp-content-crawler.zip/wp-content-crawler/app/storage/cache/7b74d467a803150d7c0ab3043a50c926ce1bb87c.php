<button class="button wcc-remove" title="<?php echo e(_wpcc("Remove")); ?>"><span class="dashicons dashicons-trash"></span></button>

<?php if(!isset($disableSort) || !$disableSort): ?>
    <div class="wcc-sort"><span class="dashicons dashicons-move"></span></div>
<?php endif; ?>