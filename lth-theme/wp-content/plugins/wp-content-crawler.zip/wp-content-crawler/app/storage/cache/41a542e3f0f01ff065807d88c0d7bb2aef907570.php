<button class="button button-primary button-large <?php echo e(isset($class) && $class ? $class : ''); ?>"
        data-toggle="tooltip" data-placement="right"
    <?php if(isset($title) && $title): ?> title="<?php echo e($title); ?>" <?php endif; ?>>
    <?php echo e(isset($text) ? $text : _wpcc('Submit')); ?>

</button>