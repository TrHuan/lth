<?php echo $__env->make('form-items/button', [
    'text'      => $isLanguagesAvailable ? _wpcc('Refresh languages') : _wpcc('Load languages'),
    // 'iconClass' => $isLanguagesAvailable ? '' : 'dashicons dashicons-warning attention',
    'buttonClass' => "load-languages {$class}",
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>