<div class="input-group custom-post-taxonomy <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <div class="input-container">
        <input type="checkbox" name="<?php echo e($name . '[append]'); ?>" id="<?php echo e($name . '[append]'); ?>" data-toggle="tooltip" title="<?php echo e(_wpcc('Append?')); ?>"
               <?php if(isset($value['append'])): ?> checked="checked" <?php endif; ?> tabindex="0">

        <input type="text" name="<?php echo e($name . '[taxonomy]'); ?>" id="<?php echo e($name . '[taxonomy]'); ?>" placeholder="<?php echo e(_wpcc('Taxonomy name...')); ?>"
               value="<?php echo e(isset($value['taxonomy']) ? $value['taxonomy'] : ''); ?>" class="meta-key" tabindex="0">

        <input type="text" name="<?php echo e($name . '[value]'); ?>" id="<?php echo e($name . '[value]'); ?>" placeholder="<?php echo e(_wpcc('Taxonomy value...')); ?>"
               value="<?php echo e(isset($value['value']) ? $value['value'] : ''); ?>" tabindex="0">
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>