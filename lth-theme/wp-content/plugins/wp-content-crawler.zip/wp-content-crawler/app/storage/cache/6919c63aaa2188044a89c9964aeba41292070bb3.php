<tr data-id="section-<?php echo e(str_slug($title)); ?>">
    <td colspan="2">
        <h4 class="section-title"><?php echo $title; ?></h4>
    </td>
</tr>