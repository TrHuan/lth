
<div class="content <?php echo $__env->yieldContent('content-class'); ?>">
    <div class="details">
        <h2>
            <span>
                
                <?php echo $__env->yieldContent('title'); ?>
            </span>

            <div class="header">
                <?php echo $__env->yieldContent('header'); ?>
            </div>
        </h2>
        <div class="inside">
            <div class="panel-wrap wcc-settings-meta-box">
                
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
</div>