
<?php echo $__env->make('tools.tools.tool-manually-recrawl', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>