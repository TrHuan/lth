

<?php if(isset($message)): ?>
    <?php echo $message; ?>

<?php endif; ?>

<?php echo $__env->make('partials.info-list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>