<?php $__env->startSection('title'); ?>
    <?php echo e(_wpcc('Manually recrawl (update) a post')); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <form action="" class="tool-form">
        

        <?php echo $__env->make('partials.form-nonce-and-action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <input type="hidden" name="tool_type" value="recrawl_post">

        <div class="panel-wrap wcc-settings-meta-box">

            <table class="wcc-settings">
                
                <tr>
                    <td>
                        <?php echo $__env->make('form-items/label', [
                            'for'   =>  '_wpcc_tools_recrawl_post_id',
                            'title' =>  _wpcc('Post ID'),
                            'info'  =>  _wpcc('Write the ID of the post you want to update.'),
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                    <td>
                        <?php echo $__env->make('form-items/text', [
                            'name'          =>  '_wpcc_tools_recrawl_post_id',
                            'type'          =>  'number',
                            'min'           =>  0,
                            'placeholder'   => _wpcc('Post ID...')
                        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </td>
                </tr>

            </table>

            <?php echo $__env->make('form-items/submit-button', [
                'text'  =>  _wpcc('Recrawl')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </form>
<?php $__env->stopSection(true); ?>
<?php echo $__env->make('tools.base.tool-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>