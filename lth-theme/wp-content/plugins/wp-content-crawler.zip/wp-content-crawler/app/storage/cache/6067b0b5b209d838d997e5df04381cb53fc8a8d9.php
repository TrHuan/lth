<div class="wcc-settings-title">
    <h3><?php echo e(_wpcc('Notifications')); ?></h3>
    <span><?php echo e(_wpcc('Set notification email addresses...')); ?></span>
</div>

<table class="wcc-settings">
    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_is_notification_active',
                'title' =>  _wpcc('Notifications are active?'),
                'info'  =>  _wpcc('If you want to activate notification emails, check this.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'  =>  '_wpcc_is_notification_active'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>
    
    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_notification_email_interval_for_site',
                'title' =>  _wpcc('Email interval'),
                'info'  =>  _wpcc("Set how many minutes should pass before sending another similar notification about
                        the same site. Default: 30")
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name'      =>  '_wpcc_notification_email_interval_for_site',
                'isOption'  =>  $isOption,
                'type'      =>  'number',
                'min'       =>  1,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_wpcc_notification_emails',
                'title' => _wpcc("Email addresses"),
                'info'  => _wpcc('Write email addresses to which notifications can be sent.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/multiple', [
                'include'       =>  'form-items/text',
                'name'          =>  '_wpcc_notification_emails',
                'type'          =>  'email',
                'remove'        =>  true,
                'addKeys'       =>  true,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    <?php

    /**
     * Fires before closing table tag in notifications tab of general settings page.
     *
     * @param array $settings       Existing settings and their values saved by user before
     * @param bool  $isGeneralPage  True if this is called from a general settings page.
     * @param bool  $isOption       True if this is an option, instead of a setting. A setting is a post meta, while
     *                              an option is a WordPress option. This is true when this is fired from general
     *                              settings page.
     * @since 1.6.3
     */
    do_action('wpcc/view/general-settings/tab/notifications', $settings, $isGeneralPage, $isOption);

    ?>

</table>