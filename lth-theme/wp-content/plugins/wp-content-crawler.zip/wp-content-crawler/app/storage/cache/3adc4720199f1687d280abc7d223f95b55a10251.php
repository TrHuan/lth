<button class="button test-this"
        data-url="<?php echo e($url); ?>"
        data-type="<?php echo e($type); ?>"
        title="<?php echo e(_wpcc('Test this URL')); ?>">
    <span class="dashicons dashicons-search"></span>
</button>