<div class="quick-save-container">
    <button type="button" class="quick-save animated"
            data-post-id="<?php echo e($postId); ?>" title="<?php echo e("Quick save"); ?>">
        <span class="dashicons dashicons-yes"></span>
    </button>
</div>