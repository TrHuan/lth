<div class="button-container <?php echo e(isset($class) ? $class : ''); ?>">
    <button class="button button-primary button-large" type="submit" id="<?php echo e(isset($id) ? $id : ''); ?>"><?php echo e(_wpcc('Save Changes')); ?></button>
</div>