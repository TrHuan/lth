<div class="input-group category-taxonomy <?php echo e(isset($remove) ? 'remove' : ''); ?> <?php echo e(isset($class) ? $class : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <div class="input-container">
        <input type="text" name="<?php echo e($name . '[taxonomy]'); ?>" id="<?php echo e($name . '[taxonomy]'); ?>" placeholder="<?php echo e(_wpcc("Taxonomy...")); ?>"
               value="<?php echo e(isset($value['taxonomy']) ? $value['taxonomy'] : ''); ?>">

        <input type="text" name="<?php echo e($name . '[description]'); ?>" id="<?php echo e($name . '[description]'); ?>" placeholder="<?php echo e(_wpcc("Name/description...")); ?>"
               value="<?php echo e(isset($value['description']) ? $value['description'] : ''); ?>">
    </div>
    <?php if(isset($remove) && $remove): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>