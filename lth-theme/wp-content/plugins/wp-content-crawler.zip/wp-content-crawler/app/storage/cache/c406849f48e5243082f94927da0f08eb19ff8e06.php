
<?php if($info): ?>
    <div>
        <span class="name"><?php echo e($name); ?></span>
        <span><?php echo e($info); ?></span>
    </div>
<?php endif; ?>