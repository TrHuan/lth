<div class="url-item">
    <?php echo $__env->make('site-tester/button-test-this', ['url' => $url, 'type' => $testType], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <a target="_blank" href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
</div>