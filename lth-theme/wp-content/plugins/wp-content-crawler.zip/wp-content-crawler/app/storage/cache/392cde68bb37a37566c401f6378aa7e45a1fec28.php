<?php

$isLanguagesAvailableGoogle = $languagesGoogleTranslateFrom && $languagesGoogleTranslateTo;
$optionsLoadLanguagesButtonGoogle = [
    'class'                 => 'google',
    'isLanguagesAvailable'  => $isLanguagesAvailableGoogle,
    'data' => [
        'selectors' => [
            'project_id' => '#_wpcc_translation_google_translate_project_id',
            'api_key'    => '#_wpcc_translation_google_translate_api_key',
        ],
        'serviceType' => \WPCCrawler\Objects\Translation\TextTranslator::KEY_GOOGLE_CLOUD_TRANSLATION,
        'requestType' => 'load_refresh_translation_languages',
    ],
];

$isLanguagesAvailableMicrosoft = $languagesMicrosoftTranslatorTextFrom && $languagesMicrosoftTranslatorTextTo;
$optionsLoadLanguagesButtonMicrosoft = [
    'class'                 => 'microsoft',
    'isLanguagesAvailable'  => $isLanguagesAvailableMicrosoft,
    'data' => [
        'selectors' => [
            'client_secret' => '#_wpcc_translation_microsoft_translate_client_secret',
        ],
        'serviceType' => \WPCCrawler\Objects\Translation\TextTranslator::KEY_MICROSOFT_TRANSLATOR_TEXT,
        'requestType' => 'load_refresh_translation_languages',
    ],
];

$optionsRefreshLanguagesLabel = [
    'title' => _wpcc('Refresh languages'),
    'info'  => _wpcc('Refresh languages by retrieving them from the API. By this way, if there are new languages, you can get them.')
];

$videoUrlGoogleCloudTranslationAPI = 'https://www.youtube.com/watch?v=imQd2pGj7-o';
$videoUrlMicrosoftTranslatorTextAPI = 'https://www.youtube.com/watch?v=VHZIQcctixY';

?>

<div class="wcc-settings-title">
    <h3><?php echo e(_wpcc('Translation')); ?></h3>
    <span><?php echo e(_wpcc('Set content translation options')); ?></span>
</div>

<table class="wcc-settings">

    <?php if($isGeneralPage): ?>
        
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', [
                    'for'   =>  '_wpcc_is_translation_active',
                    'title' =>  _wpcc('Translation is active?'),
                    'info'  =>  _wpcc('If you want to activate automated content translation, check this. Note that
                            translating will increase the time required to crawl a post.')
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/checkbox', [
                    'name' => '_wpcc_is_translation_active',
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_selected_translation_service',
                'title' =>  _wpcc('Translate with'),
                'info'  =>  _wpcc('Select the translation service you want to use to translate contents. You also need
                    to properly configure the settings of the selected API below.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/select', [
                'name'      =>  '_wpcc_selected_translation_service',
                'options'   =>  $translationServices,
                'isOption'  =>  $isOption,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <?php echo $__env->make('partials.table-section-title', ['title' => _wpcc("Google Cloud Translation Options")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_google_translate_from',
                'title' =>  _wpcc('Translate from'),
                'info'  =>  _wpcc('Select the language of the content of crawled posts.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableGoogle): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_wpcc_translation_google_translate_from',
                    'options'   =>  $languagesGoogleTranslateFrom,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle + ['id' => '_wpcc_translation_google_translate_from'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_google_translate_to',
                'title' =>  _wpcc('Translate to'),
                'info'  =>  _wpcc('Select the language to which the content should be translated.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableGoogle): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_wpcc_translation_google_translate_to',
                    'options'   =>  $languagesGoogleTranslateTo,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle + ['id' => '_wpcc_translation_google_translate_to'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <?php if($isLanguagesAvailableGoogle): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', $optionsRefreshLanguagesLabel, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonGoogle, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_google_translate_project_id',
                'title' =>  _wpcc('Project ID'),
                'info'  =>  _wpcc('Project ID retrieved from Google Cloud Console.') . ' ' . _wpcc_trans_how_to_get_it($videoUrlGoogleCloudTranslationAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_wpcc_translation_google_translate_project_id',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_google_translate_api_key',
                'title' =>  _wpcc('API Key'),
                'info'  =>  _wpcc('API key retrieved from Google Cloud Console.') . ' ' . _wpcc_trans_how_to_get_it($videoUrlGoogleCloudTranslationAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_wpcc_translation_google_translate_api_key',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_google_translate_test',
                'title' =>  _wpcc('Test Google Translate Options'),
                'info'  =>  _wpcc('You can write any text to test Google Translate options you configured.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_wpcc_translation_google_translate_test',
                'placeholder'   =>  _wpcc('Test text to translate...'),
                'data'          =>  [
                    'apiKeySelector'    => '#_wpcc_translation_google_translate_api_key',
                    'projectIdSelector' => '#_wpcc_translation_google_translate_project_id',
                    'fromSelector'      => '#_wpcc_translation_google_translate_from',
                    'toSelector'        => '#_wpcc_translation_google_translate_to',
                    'testType'          =>  \WPCCrawler\Test\Test::$TEST_TYPE_TRANSLATION,
                    'serviceType'       =>  \WPCCrawler\Objects\Translation\TextTranslator::KEY_GOOGLE_CLOUD_TRANSLATION,
                    'requiredSelectors' =>  "#_wpcc_translation_google_translate_test & #_wpcc_translation_google_translate_api_key & #_wpcc_translation_google_translate_project_id & #_wpcc_translation_google_translate_from & #_wpcc_translation_google_translate_to"
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'wcc-test-translation google-translate',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <?php echo $__env->make('partials.table-section-title', ['title' => _wpcc("Microsoft Translator Text Options")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_microsoft_translate_from',
                'title' =>  _wpcc('Translate from'),
                'info'  =>  _wpcc('Select the language of the content of crawled posts.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableMicrosoft): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      => '_wpcc_translation_microsoft_translate_from',
                    'options'   => $languagesMicrosoftTranslatorTextFrom,
                    'isOption'  => $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft + ['id' => '_wpcc_translation_microsoft_translate_from'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_microsoft_translate_to',
                'title' =>  _wpcc('Translate to'),
                'info'  =>  _wpcc('Select the language to which the content should be translated.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php if($isLanguagesAvailableMicrosoft): ?>
                <?php echo $__env->make('form-items/select', [
                    'name'      =>  '_wpcc_translation_microsoft_translate_to',
                    'options'   =>  $languagesMicrosoftTranslatorTextTo,
                    'isOption'  =>  $isOption,
                ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft + ['id' => '_wpcc_translation_microsoft_translate_to'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </td>
    </tr>

    
    <?php if($isLanguagesAvailableMicrosoft): ?>
        <tr>
            <td>
                <?php echo $__env->make('form-items/label', $optionsRefreshLanguagesLabel, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
            <td>
                <?php echo $__env->make('form-items/partials/button-load-languages', $optionsLoadLanguagesButtonMicrosoft, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </td>
        </tr>
    <?php endif; ?>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_microsoft_translate_client_secret',
                'title' =>  _wpcc('Client Secret'),
                'info'  =>  _wpcc('Client secret retrieved from Microsoft Azure Portal.') . ' ' . _wpcc_trans_how_to_get_it($videoUrlMicrosoftTranslatorTextAPI)
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/text', [
                'name' => '_wpcc_translation_microsoft_translate_client_secret',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_wpcc_translation_microsoft_translate_test',
                'title' =>  _wpcc('Test Microsoft Translator Text Options'),
                'info'  =>  _wpcc('You can write any text to test Microsoft Translator Text options you configured.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_wpcc_translation_microsoft_translate_test',
                'placeholder'   =>  _wpcc('Test text to translate...'),
                'data'          =>  [
                    'clientSecretSelector'  => '#_wpcc_translation_microsoft_translate_client_secret',
                    'fromSelector'          => '#_wpcc_translation_microsoft_translate_from',
                    'toSelector'            => '#_wpcc_translation_microsoft_translate_to',
                    'testType'              =>  \WPCCrawler\Test\Test::$TEST_TYPE_TRANSLATION,
                    'serviceType'           =>  \WPCCrawler\Objects\Translation\TextTranslator::KEY_MICROSOFT_TRANSLATOR_TEXT,
                    'requiredSelectors'     =>  "#_wpcc_translation_microsoft_translate_test & #_wpcc_translation_microsoft_translate_client_secret & #_wpcc_translation_microsoft_translate_from & #_wpcc_translation_microsoft_translate_to"
                ],
                'addon'         =>  'dashicons dashicons-search',
                'test'          =>  true,
                'addonClasses'  => 'wcc-test-translation microsoft-translator-text',
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    <?php

    /**
     * Fires before closing table tag in translation tab of general settings page.
     *
     * @param array $settings       Existing settings and their values saved by user before
     * @param bool  $isGeneralPage  True if this is called from a general settings page.
     * @param bool  $isOption       True if this is an option, instead of a setting. A setting is a post meta, while
     *                              an option is a WordPress option. This is true when this is fired from general
     *                              settings page.
     * @since 1.6.3
     */
    do_action('wpcc/view/general-settings/tab/translation', $settings, $isGeneralPage, $isOption);

    ?>

</table>