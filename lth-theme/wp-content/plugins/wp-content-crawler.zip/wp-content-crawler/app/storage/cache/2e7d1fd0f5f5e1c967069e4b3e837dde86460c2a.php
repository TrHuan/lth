<?php if($site): ?>
    <span class="site">
        <a href="<?php echo get_edit_post_link($site->ID); ?>" target="_blank">
            <?php echo e($site->post_title); ?>

        </a>
    </span>
<?php endif; ?>