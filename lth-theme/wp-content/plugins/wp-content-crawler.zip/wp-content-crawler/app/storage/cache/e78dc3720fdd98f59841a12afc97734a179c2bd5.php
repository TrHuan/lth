<?php /** @var \WPCCrawler\Objects\File\MediaFile $item */ ?>
<div class="attachment-item">
    
    <div>
        <?php if($item->isGalleryImage()): ?>
            <span class="name"><?php echo e(_wpcc("Gallery Item")); ?></span>
        <?php endif; ?>
        <span><a href="<?php echo e($item->getLocalUrl()); ?>" target="_blank"
           <?php if(isset($tooltip) && $tooltip): ?>
             data-html="true" data-toggle="tooltip" title="<img src='<?php echo e($item->getLocalUrl()); ?>'>"
           <?php endif; ?>>
            <?php echo e($item->getLocalUrl()); ?>

        </a></span>
    </div>

    
    <?php echo $__env->make('site-tester.partial.attachment-item-info', [
        'name' => _wpcc('Title'),
        'info' => $item->getMediaTitle()
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('site-tester.partial.attachment-item-info', [
        'name' => _wpcc('Description'),
        'info' => $item->getMediaDescription()
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('site-tester.partial.attachment-item-info', [
        'name' => _wpcc('Caption'),
        'info' => $item->getMediaCaption()
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php echo $__env->make('site-tester.partial.attachment-item-info', [
        'name' => _wpcc('Alternate text'),
        'info' => $item->getMediaAlt()
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <?php if($item->getCopyFileUrls()): ?>
        <div>
            <span class="name"><?php echo e(_wpcc('Copy file URLs')); ?></span>
            <ol>
                <?php $__currentLoopData = $item->getCopyFileUrls(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $copyFileUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e($copyFileUrl); ?>" target="_blank"
                        <?php if(isset($tooltip) && $tooltip): ?>
                            data-html="true" data-toggle="tooltip" title="<img src='<?php echo e($item->getLocalUrl()); ?>'>"
                        <?php endif; ?>>
                            <?php echo e($copyFileUrl); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    <?php endif; ?>
</div>