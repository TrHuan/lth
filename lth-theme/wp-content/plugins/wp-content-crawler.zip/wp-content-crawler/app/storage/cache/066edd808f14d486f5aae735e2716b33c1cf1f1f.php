<?php $__env->startSection('content-class'); ?> <?php $__env->stopSection(true); ?>
<?php $__env->startSection('header'); ?> <?php $__env->stopSection(true); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e(_wpcc("Active sites")); ?> (<?php echo e(sizeof($activeSites)); ?>)
<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!empty($activeSites)): ?>
        <table class="section-table detail-card white">
            <thead>
                <tr>
                    <th></th>
                    <th><?php echo e(_wpcc("Last")); ?></th>
                    <th><?php echo e(_wpcc("Active")); ?></th>
                    <th><?php echo e(_wpcc("Today")); ?></th>
                    <th><?php echo e(_wpcc("All")); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $activeSites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeSite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="site-name">
                            <a href="<?php echo get_edit_post_link($activeSite->ID); ?>" target="_blank">
                                <?php echo e($activeSite->post_title); ?>

                            </a>
                        </td>
                        <td>
                            <?php
                                $lastEventDates = [
                                    _wpcc("URL Collection") => $activeSite->lastCheckedAt,
                                    _wpcc("Post Crawl")     => $activeSite->lastCrawledAt,
                                    _wpcc("Post Recrawl")   => $activeSite->lastRecrawledAt,
                                    _wpcc("Post Delete")    => $activeSite->lastDeletedAt
                                ];
                            ?>

                            <?php $__currentLoopData = $lastEventDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventName => $dateStr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><span><?php echo e($eventName); ?>:</span> <span class="diff-for-humans"><?php echo sprintf(_wpcc('%1$s ago'), \WPCCrawler\Utils::getDiffForHumans(strtotime($dateStr))); ?></span> <span class="date">(<?php echo e(\WPCCrawler\Utils::getDateFormatted($dateStr)); ?>)</span> </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php
                                $activeStatuses = [
                                    _wpcc("Scheduling") => $activeSite->activeScheduling,
                                    _wpcc("Recrawling") => $activeSite->activeRecrawling,
                                    _wpcc("Deleting") => $activeSite->activeDeleting
                                ];
                            ?>

                            <?php $__currentLoopData = $activeStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventName => $isActive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><span><?php echo e($eventName); ?></span>: <span class="dashicons dashicons-<?php echo e($isActive ? 'yes' : 'no'); ?>"></span></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php
                                $countsToday = [
                                    _wpcc("Queue")   => $activeSite->countQueueToday,
                                    _wpcc("Saved")   => $activeSite->countSavedToday,
                                    _wpcc("Updated") => $activeSite->countRecrawledToday,
                                    _wpcc("Deleted") => $activeSite->countDeletedToday,
                                ];
                            ?>

                            <?php $__currentLoopData = $countsToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mName => $mValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><span><?php echo e($mName); ?>:</span> <?php echo e($mValue); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php
                                $countsAll = [
                                    _wpcc("Queue")   => $activeSite->countQueue,
                                    _wpcc("Saved")   => $activeSite->countSaved,
                                    _wpcc("Updated") => $activeSite->countRecrawled,
                                    _wpcc("Deleted") => $activeSite->countDeleted,
                                ];
                            ?>

                            <?php $__currentLoopData = $countsAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mName => $mValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><span><?php echo e($mName); ?>:</span> <?php echo e($mValue); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php else: ?>

        <?php echo e(_wpcc("No active sites.")); ?>


    <?php endif; ?>

<?php $__env->stopSection(true); ?>
<?php echo $__env->make('dashboard.partials.section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>