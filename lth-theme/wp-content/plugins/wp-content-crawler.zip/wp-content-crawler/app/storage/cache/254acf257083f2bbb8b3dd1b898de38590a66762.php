<div class="description">
    <?php echo e(_wpcc('You can create templates for the current item. You can use the short codes below. In addition, you can
        use custom short codes you defined in the settings. When there are more than one template, a random one
        will be selected for each found item. When testing, find-replace, general, and calculation options will be
        applied first.')); ?>

</div>

<?php echo $__env->make('form-items.partials.short-code-buttons', [
    'buttons' => $buttonsOptionsBoxTemplates,
], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<table class="wcc-settings">

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_options_box[remove_if_empty]',
                'title' =>  _wpcc('Remove item if it is empty?'),
                'info'  =>  _wpcc('When you check this, if the item is found to be empty, it will be removed from the results.
                    In other words, it will be treated as it was not found. It will not be included in the results.
                    The templates will not be applied.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/checkbox', [
                'name'  => '_options_box[remove_if_empty]'
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   =>  '_options_box[templates]',
                'title' =>  _wpcc('Templates'),
                'info'  =>  _wpcc('Define your templates here. If there are more than one, a random template will be
                        selected.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/multiple', [
                'include'       =>  'form-items/textarea',
                'name'          =>  '_options_box[templates]',
                'inputKey'      =>  'template',
                'placeholder'   =>  _wpcc('Template'),
                'addKeys'       =>  true,
                'remove'        =>  true,
                'addon'         =>  'dashicons dashicons-search',
                'data'          =>  [
                    'testType'  =>  \WPCCrawler\Test\Test::$TEST_TYPE_TEMPLATE,
                    'extra'     =>  $dataExtra
                ],
                'test'          =>  true,
                'addonClasses'  => 'wcc-test-template',
                'showButtons'   => false,
                'rows'          => 4
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials/test-result-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

</table>