<div class="input-group category-map <?php echo e(isset($addon) ? 'addon' : ''); ?> <?php echo e(isset($remove) ? 'remove' : ''); ?>" <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>
    <?php if(isset($addon)): ?>
        <?php echo $__env->make('form-items.partials.button-addon-test', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
    <div class="input-container">
        <?php $selectedId = isset($value['cat_id']) ? $value['cat_id'] : null; ?>

        <?php echo $__env->make('form-items.partials.categories', [
            'selectedId'        => $selectedId,
            'name'              => $name . '[cat_id]',
            'categories'        => $categories,
            'taxonomyInputName' => $name . '[taxonomy]',
            'addTaxonomyInput'  => true
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <input type="text" id="<?php echo e(isset($name) ? $name . '[url]' : ''); ?>" name="<?php echo e(isset($name) ? $name . '[url]' : ''); ?>" value="<?php echo e(isset($value["url"]) ? $value['url'] : ''); ?>" placeholder="<?php echo e(isset($placeholder) ? $placeholder : ''); ?>" />
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>