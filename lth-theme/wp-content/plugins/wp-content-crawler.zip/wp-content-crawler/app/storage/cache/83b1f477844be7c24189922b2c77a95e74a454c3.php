<div class="input-group domains <?php echo e(isset($remove) ? 'remove' : ''); ?>"
     <?php if(isset($dataKey)): ?> data-key="<?php echo e($dataKey); ?>" <?php endif; ?>>

    <div class="input-container">
        <input type="text" name="<?php echo e($name . '[domain]'); ?>" id="<?php echo e($name . '[domain]'); ?>" placeholder="<?php echo e(_wpcc('Domain...')); ?>"
               value="<?php echo e(isset($value['domain']) ? $value['domain'] : ''); ?>"
               class="post-url"
               tabindex="0">
    </div>
    <?php if(isset($remove)): ?>
        <?php echo $__env->make('form-items/remove-button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>