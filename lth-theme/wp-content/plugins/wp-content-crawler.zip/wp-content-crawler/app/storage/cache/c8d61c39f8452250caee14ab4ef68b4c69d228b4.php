<div class="description">
    <?php echo e(_wpcc('You can take notes about the options you configured, or anything. This tab is just for taking notes.')); ?>

</div>

<table class="wcc-settings">
    <tr>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          => '_options_box[note]',
                'rows'          => 6,
                'showButtons'   => false,
                'placeholder'   =>  _wpcc('Notes...'),
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

</table>