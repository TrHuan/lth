<div class="description">
    <?php echo e(_wpcc('Import or export options box settings.')); ?>

</div>

<table class="wcc-settings">

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_options_box_import_settings',
                'title' => _wpcc('Import Settings'),
                'info'  => _wpcc('Paste the settings exported from another options box to import. <b>Current settings
                    will be overridden.</b>')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_options_box_import_settings',
                'placeholder'   =>  _wpcc('Paste settings and click the import button. Note: This will override all settings.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('form-items.button', [
                'buttonClass' => 'options-box-import',
                'text' => _wpcc("Import")
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

    
    <tr>
        <td>
            <?php echo $__env->make('form-items/label', [
                'for'   => '_options_box_export_settings',
                'title' => _wpcc('Export Settings'),
                'info'  => _wpcc('You can copy the settings here and use the copied code to export settings to
                    another options box.')
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
        <td>
            <?php echo $__env->make('form-items/textarea', [
                'name'          =>  '_options_box_export_settings',
                'readOnly'      =>  true,
                'noName'        =>  true,
            ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </td>
    </tr>

</table>