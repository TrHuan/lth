<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 10/01/17
 * Time: 13:28
 */

namespace WPCCrawler\Objects\Crawling\Bot;


class DummyBot extends AbstractBot {

}