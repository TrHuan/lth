<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 14/12/2018
 * Time: 12:56
 *
 * @since 1.8.0
 */

namespace WPCCrawler\Exceptions;


class MethodNotExistException extends \Exception {

}