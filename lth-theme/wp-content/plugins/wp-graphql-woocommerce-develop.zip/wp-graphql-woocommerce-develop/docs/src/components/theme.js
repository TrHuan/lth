export default {
  fonts: {
    mono: '"SF Mono", "Roboto Mono", Menlo, monospace'
  }
};
